const express = require('express');
const { listen } = require('express/lib/application');
const Produto = require('./produto');
const app = express();
app.use(express.urlencoded({extended: true}))
app.use(express.json())

app.get("/", function(req, res){
    res.sendFile(__dirname+"/html/index.html")
})

app.post("/delete", function(req, res){
    (async ()=> {
    const database = require('./db');
    const Produto = require('./produto');
    await database.sync();

    const produtos = await Produto.findByPk(req.body.ide); 
    produtos.destroy();
    })();
    res.send(`O Produto com ID: ${req.body.ide} <br> Foi Deletado do Banco de dados com sucesso!`);

})

app.post("/editar", function(req, res){
    (async ()=> {
    const database = require('./db');
    const Produto = require('./produto');
    await database.sync();

    const produtos = await Produto.findByPk(req.body.ide); 
    produtos.nome = req.body.nome,
    produtos.preco = req.body.preco,
    descricao = req.body.descricao
    produtos.save();
    
    })();
    res.send(`O Produto com ID: ${req.body.ide} <br> Foi Editado no Banco de dados com sucesso!`);

})

app.post('/posts', function (req, res) {
       (async ()=> {

    const database = require('./db');
    const Produto = require('./produto');
    await database.sync();

    const novoProduto = await Produto.create({
        nome: req.body.nome,
        preco: req.body.preco,
        descricao: req.body.descricao
    })
    res.send(`O Produto: ${req.body.nome} <br> Valor: ${req.body.preco} <br> Descrição: ${req.body.descricao} <br> Foi adicionado ao Banco de dados com sucesso!`) 

    })();

});

app.post('/consulta', function (req, res) {
    (async ()=> {
        const database = require('./db');
        const Produto = require('./produto');
        await database.sync();
    
        const produtos = await Produto.findByPk(req.body.ide); 
        console.log(produtos);
        })();
        res.send(`O Produto Consultado está no Console`)

});

app.post('/consultatudo', function (req, res) {
    (async ()=> {
        const database = require('./db');
        const Produto = require('./produto');
        await database.sync();
    
        const produtos = await Produto.findAll(); 
        console.log(produtos);
        })();
        res.send(`Os Produtos Consultado estão no Console`)

});

app.listen(3000);